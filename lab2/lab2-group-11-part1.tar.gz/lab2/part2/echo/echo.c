/** @file echo.c
 *
 * @author  Harry Q Bovik (Change this!)
 * @date    The current date
 */


int main(int argc, char** argv) {

	/* Put your code here */

	return -255;
}

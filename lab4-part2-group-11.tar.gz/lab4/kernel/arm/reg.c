#include <types.h>

#define IMPLEMENTATION
#include <arm/reg.h>
